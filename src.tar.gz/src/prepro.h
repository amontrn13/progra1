#ifndef PREPRO_H
#define PREPRO_H

#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

FILE *temp, *fp1;

void createTempFile(char *fileName);
FILE* getTempFile();

#endif /* PREPRO_H */
