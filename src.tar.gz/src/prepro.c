#include "prepro.h"

//la variable temp fue declara en header

void createTempFile(char *fileName)
{
	temp = fopen ("sourceTemp.txt", "w");
	fp1 = fopen(fileName, "r");
	char ch;
   	//clrscr();

	if (temp==NULL)
	{
		fputs ("	File error",stderr); 
	}
	else 
	{
		printf("Temporary file 'sourceTemp'created\n");
	}

   	while (1) 
	{
      		ch = fgetc(fp1);
      		if (ch == EOF)
	        	break;
      		else
         		putc(ch, temp);
  	}
 
   printf("File copied successfully");
   fclose(temp);
   fclose(fp1);
}

FILE* getTempFile()
{
	return temp;
}


