
//#include <unistd.h>
#include "prepro.h"
#include "scanner.h"


void initScanner(char *fileName)
{
	printf("Init prepocess...\n");
	//se llama al preprocesador
	createTempFile(fileName);
}
